👋 Hi, I’m [Barbu George](https://github.com/george-barbu-cc)  
👀 I’m interested in web developing   
🧙 Web developer with more than 7 years of experience   
💞️ Currently learning ReactJS   
📫 How to reach me email adress: george@barbu.cc 
